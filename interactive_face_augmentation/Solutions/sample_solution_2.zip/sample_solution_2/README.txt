'||''|.   '||''''|      |     '||''|.   '||    ||' '||''''|  
 ||   ||   ||  .       |||     ||   ||   |||  |||   ||  .    
 ||''|'    ||''|      |  ||    ||    ||  |'|..'||   ||''|    
 ||   |.   ||        .''''|.   ||    ||  | '|' ||   ||       
.||.  '|' .||.....| .|.  .||. .||...|'  .|. | .||. .||.....|

Karl Lopker
klopker@cs.ucsb.edu
Homework 2
CS290I W12
____________________________________________________________

main
------------------------------------------------------------
Compile:
Run "cmake ." then "make".

Usage: ./main [video file]

Add the name of a video file to run the program on,
otherwise your default webcam will be used.

The default selection method is background subtraction. This
is what is being used when the picture is in color. Velocity
vector is only active on the second click of g.

Keyboard:

q - quit
o - cycle between objects
g - switch between selection modes
r - cycle between rectangle modes
b - update background in background subtraction mode

____________________________________________________________

Sources used
------------------------------------------------------------
www710.univ-lyon1.fr/~jciehl/Public/OpenGL_PG/ch06.html
code.ros.org/trac/opencv/browser/trunk/opencv/samples/cpp/fback.cpp
www.cplusplus.com/forum/articles/13355/
www.colorpicker.com/
chris.com/ascii/index.php?art=creatures/dragons

                         .       .
                        / `.   .' \
                .---.  <    > <    >  .---.
                |    \  \ - ~ ~ - /  /    |
                 ~-..-~             ~-..-~
    sup      \~~~\.'                    `./~~~/
   .-~~^-.    \__/                        \__/
 .'  O    \     /               /       \  \
(_____,    `._.'               |         }  \/~~~/
 `----.          /       }     |        /    \__/
       `-.      |       /      |       /      `. ,~~|
           ~-.__|      /_ - ~ ^|      /- _      `..-'   f: f:
                |     /        |     /     ~-.     `-. _||_||_
                |_____|        |_____|         ~ - . _ _ _ _ _>